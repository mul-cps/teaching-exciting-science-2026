<!-- Generated from curriculum/workshop.json; edit the source, then run tools/build_notebooks.py. -->

# Robot factory worksheet

Build an offline robot factory from ordered instructions. Start with one fixed pickup fixture and one fixed destination. Pair roles: driver edits; observer predicts and checks; swap halfway. Only the instructor enables supervised hardware.

Pair names: __________________  Driver first: __________  Observer first: __________

| Minutes | Duration | Session |
|---|---|---|
| 0-20 | 20 | Meet our factory |
| 20-45 | 25 | Ordered instructions |
| 45-65 | 20 | Observations and uncertainty |
| 65-95 | 30 | First Python edits |
| 95-105 | 10 | Break |
| 105-120 | 15 | Teach inspect and replay demonstration |
| 120-165 | 45 | Explore three stations |
| 165-210 | 45 | Build the physical sequence |
| 210-230 | 20 | Improve one failure |
| 230-240 | 10 | Three pair demonstrations |

## Make a short conveyor story

Put instructions in order and repeat a small section.

Predict: ______________________________

One change: ___________________________

Run and observed evidence: ______________________________

Explain and limit: ______________________________

Evidence source (circle): PAPER / SIMULATION / PHYSICAL

Success check: Your pair can trace the order, predict a repeat count and explain one corrected sequence.

## Separate the object from its report

Recognise missing and incorrect observations.

Predict: ______________________________

One change: ___________________________

Run and observed evidence: ______________________________

Explain and limit: ______________________________

Evidence source (circle): PAPER / SIMULATION / PHYSICAL

Success check: You identify one missing and one wrong report and choose pause/inspect for uncertainty.

## Change a name and a number

Read and edit a short Python program before sharing the same program representation with blocks.

Predict: ______________________________

One change: ___________________________

Run and observed evidence: ______________________________

Explain and limit: ______________________________

Evidence source (circle): PAPER / SIMULATION / PHYSICAL

Success check: Both partners make one edit and explain it; shared commands are validated before execution.

## Watch teach inspect return replay

Understand that a recorded stroke needs validated start/end poses and explicit jaw state.

Predict: ______________________________

One change: ___________________________

Run and observed evidence: ______________________________

Explain and limit: ______________________________

Evidence source (circle): PAPER / SIMULATION / PHYSICAL

Success check: You can say teach → inspect/validate → return to start → replay, and point to STOP.

## Explore three stations

Connect observations, instructions and the robot model.

Predict: ______________________________

One change: ___________________________

Run and observed evidence: ______________________________

Explain and limit: ______________________________

Evidence source (circle): PAPER / SIMULATION / PHYSICAL

Success check: Every pair completes all three positions with one recorded prediction and evidence statement per position.

## Dispense carry pick and place

Assemble the supervised fixed pickup to fixed destination sequence.

Predict: ______________________________

One change: ___________________________

Run and observed evidence: ______________________________

Explain and limit: ______________________________

Evidence source (circle): PAPER / SIMULATION / PHYSICAL

Success check: Your pair explains the full fixed-fixture sequence and records honest per-step evidence. Physical completion requires observed object transfer; offline completion is labelled rehearsal.

## Find one failure and test a repair

Use a controlled change and evidence to improve a sequence.

Predict: ______________________________

One change: ___________________________

Run and observed evidence: ______________________________

Explain and limit: ______________________________

Evidence source (circle): PAPER / SIMULATION / PHYSICAL

Success check: You show a failing prediction, one repair and a repeated check with its limits.

## Show one prediction and result

Explain what your program did and what the evidence cannot prove.

Predict: ______________________________

One change: ___________________________

Run and observed evidence: ______________________________

Explain and limit: ______________________________

Evidence source (circle): PAPER / SIMULATION / PHYSICAL

Success check: All three pairs demonstrate and state a specific limitation.
