"""Out-of-process 10 Hz accounting; never subscribes to ROS or pixels."""
import argparse, json, os, pathlib, signal, time
p=argparse.ArgumentParser(); p.add_argument('--pid',action='append',required=True);p.add_argument('--output',required=True);a=p.parse_args()
targets={name:int(pid) for name,pid in (s.split(':',1) for s in a.pid)}; running=True

def stop(*_):
 global running
 running=False
signal.signal(signal.SIGINT,stop);signal.signal(signal.SIGTERM,stop)
with open(a.output,'w',buffering=1) as out:
 while running:
  begin=time.monotonic();row={'monotonic':begin,'clock_ticks_per_second':os.sysconf('SC_CLK_TCK'),'processes':{}}
  row['host_cpu_ticks']=list(map(int,pathlib.Path('/proc/stat').read_text().splitlines()[0].split()[1:9]))
  for name,pid in targets.items():
   root=pathlib.Path('/proc')/str(pid)
   try:
    tail=(root/'stat').read_text().rsplit(')',1)[1].split();s={'pid':pid,'cpu_ticks':int(tail[11])+int(tail[12]),'starttime_ticks':int(tail[19]),'rss_pages':int(tail[21]),'drm_clients':{}}
    for f in (root/'fdinfo').iterdir():
     try:
      text=f.read_text()
      if 'drm-client-id:' not in text:continue
      fields={k:v.strip() for line in text.splitlines() if ':' in line for k,v in [line.split(':',1)] if k.startswith('drm-')}
      s['drm_clients'][fields['drm-client-id']]=fields
     except (FileNotFoundError,PermissionError,ProcessLookupError):pass
    row['processes'][name]=s
   except (FileNotFoundError,PermissionError,ProcessLookupError):row['processes'][name]={'pid':pid,'missing':True}
  row['sampling_cost_seconds']=time.monotonic()-begin;out.write(json.dumps(row)+'\n');time.sleep(max(0,.1-(time.monotonic()-begin)))
