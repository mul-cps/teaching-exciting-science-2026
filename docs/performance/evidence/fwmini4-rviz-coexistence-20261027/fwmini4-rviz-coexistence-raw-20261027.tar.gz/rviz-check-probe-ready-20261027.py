import json,pathlib,sys
records=[]
for line in pathlib.Path(sys.argv[1]).read_text(errors='replace').splitlines():
 try:row=json.loads(line)
 except json.JSONDecodeError:continue
 if isinstance(row,dict) and row.get('event'):records.append(row)
errors=[r for r in records if r.get('event') in ('symbol_error','clock_error','slot_limit')]
renderers=[r for r in records if r.get('event')=='renderer']
assert not errors,errors
assert renderers,'No intercepted GLX swaps: frame measurement invalid'
assert all(r.get('metadata_complete') and r.get('direct') and 'Intel' in r.get('renderer','') and not any(x in r.get('renderer','').lower() for x in ('llvmpipe','softpipe','swrast','software')) for r in renderers),renderers
viewports=[r for r in records if r.get('event')=='interval' and r.get('width',0)>=400 and r.get('height',0)>=400]
assert viewports,'No measured main-sized viewport interval'
print(json.dumps({'passed':True,'renderers':renderers,'main_sized_intervals':len(viewports),'last_main_sized_interval':viewports[-1]}))
