#!/usr/bin/env python3
"""Capture only the RViz client window, never the X root window.

Run after timed GPU measurements: grabWindow is a pixel readback. Window lookup
uses xwininfo -root -tree metadata, then config filename + RViz WM_CLASS and an
optional native RViz PID. Rootless Xwayland's root pixels are never captured.
Pure parsing is importable without Qt, DISPLAY or an X connection.
"""
import argparse
import json
import os
from pathlib import Path
import re
import subprocess
import sys

WINDOW_LINE = re.compile(
    r'^\s*(?P<xid>0x[0-9a-fA-F]+)\s+'
    r'(?P<title>"(?:\\.|[^"\\])*"):\s*'
    r'\("(?P<instance>[^"]*)"\s+"(?P<class>[^"]*)"\)\s+'
    r'(?P<width>\d+)x(?P<height>\d+)(?P<x>[+-]\d+)(?P<y>[+-]\d+)')


def parse_xwininfo_tree(text):
    windows = []
    for line in text.splitlines():
        match = WINDOW_LINE.match(line)
        if not match:
            continue
        fields = match.groupdict()
        window = {'xid': int(fields['xid'], 16), 'title': json.loads(fields['title']),
                  'instance': fields['instance'], 'class': fields['class'],
                  **{name: int(fields[name]) for name in ('width', 'height', 'x', 'y')}}
        if window['xid'] and window['width'] > 0 and window['height'] > 0:
            windows.append(window)
    return windows


def parse_xprop_pid(text):
    match = re.search(r'^_NET_WM_PID(?:\([^)]*\))?\s*=\s*([1-9][0-9]*)\s*$', text, re.MULTILINE)
    return int(match.group(1)) if match else None


def lookup_pid(xid):
    result = subprocess.run(['xprop', '-id', hex(xid), '_NET_WM_PID'], capture_output=True, text=True, timeout=5, check=True)
    return parse_xprop_pid(result.stdout)


def select_rviz_window(windows, config_filename, expected_pid=None, pid_lookup=None):
    if not config_filename or expected_pid is not None and expected_pid <= 0:
        raise ValueError('nonempty configuration filename and a positive optional PID are required')
    candidates = [window for window in windows if config_filename in window['title']
                  and window['class'].casefold() in ('rviz', 'rviz2')
                  and window['xid'] != 0 and window['width'] > 0 and window['height'] > 0]
    if expected_pid is not None:
        getter = lookup_pid if pid_lookup is None else pid_lookup
        candidates = [window for window in candidates if getter(window['xid']) == expected_pid]
    if not candidates:
        raise RuntimeError('no RViz client window matches the configuration filename and optional PID')
    if len(candidates) != 1:
        raise RuntimeError('ambiguous RViz windows: supply --pid for the current native RViz process; matching XIDs=' + ','.join(hex(w['xid']) for w in candidates))
    return candidates[0]


def capture_window(window, output):
    # Qt loads only when a caller explicitly asks for a real window capture.
    if not os.environ.get('DISPLAY'):
        raise RuntimeError('DISPLAY must name the caller-authorized private X display')
    platform = os.environ.get('QT_QPA_PLATFORM', 'xcb')
    if platform.split(':', 1)[0] != 'xcb':
        raise RuntimeError('this helper requires QT_QPA_PLATFORM=xcb for the selected X11 WId')
    os.environ['QT_QPA_PLATFORM'] = 'xcb'
    from PyQt5.QtWidgets import QApplication
    from PyQt5.QtGui import QGuiApplication
    app = QApplication.instance() or QApplication(['rviz-window-capture'])
    screen = QGuiApplication.primaryScreen()
    if screen is None:
        raise RuntimeError('Qt reports no screen on the authorized X display')
    xid = window['xid']
    if not xid:
        raise RuntimeError('refusing root/null WId capture')
    pixmap = screen.grabWindow(xid)
    if pixmap.isNull() or pixmap.width() <= 0 or pixmap.height() <= 0:
        raise RuntimeError('Qt grabWindow returned an empty RViz pixmap')
    output.parent.mkdir(parents=True, exist_ok=True)
    if not pixmap.save(str(output), 'PNG'):
        raise RuntimeError('Qt could not save the RViz client PNG')
    return {'png': str(output.resolve()), 'pixel_width': pixmap.width(), 'pixel_height': pixmap.height(),
            'device_pixel_ratio': pixmap.devicePixelRatio(), 'qt_platform': QGuiApplication.platformName(),
            'capture_api': 'QScreen.grabWindow(selected_RViz_WId)', 'root_pixels_captured': False,
            'child_gl_content_verified': False,
            'child_gl_content_note': 'Child/OpenGL viewport inclusion depends on X11/Qt/compositor behavior. Inspect the PNG; missing or black child surfaces are not a scene-content pass.',
            'measurement_note': 'Post-timing UI validation only; this capture performs pixel readback.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--config-filename', default='rviz-coexistence.rviz', help='Filename fragment shown in the current RViz title')
    parser.add_argument('--pid', type=int, help='Native RViz PID, recommended to exclude stale windows')
    parser.add_argument('--output', type=Path, default=Path('/tmp/rviz-window-20261027.png'))
    parser.add_argument('--tree-file', type=Path, help='Offline xwininfo text fixture; requires --select-only')
    parser.add_argument('--select-only', action='store_true', help='Report selected window metadata without Qt initialization or pixel capture')
    args = parser.parse_args()
    if args.tree_file and not args.select_only:
        parser.error('--tree-file requires --select-only; offline fixtures cannot authorize a capture')
    if args.tree_file and args.pid is not None:
        parser.error('--tree-file cannot query a live PID; unit tests inject PID lookup separately')
    if args.tree_file:
        tree = args.tree_file.read_text()
    else:
        if not os.environ.get('DISPLAY'):
            raise RuntimeError('DISPLAY must name the caller-authorized private X display')
        tree = subprocess.run(['xwininfo', '-root', '-tree'], capture_output=True, text=True, timeout=5, check=True).stdout
    window = select_rviz_window(parse_xwininfo_tree(tree), args.config_filename, args.pid)
    result = {'window': {**window, 'xid_hex': hex(window['xid'])}, 'expected_pid': args.pid}
    if not args.select_only:
        result.update(capture_window(window, args.output))
        args.output.with_suffix('.json').write_text(json.dumps(result, indent=2, sort_keys=True)+'\n')
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (OSError, ValueError, RuntimeError, subprocess.SubprocessError) as error:
        print('RViz window capture refused: ' + str(error), file=sys.stderr)
        raise SystemExit(2)
