#!/bin/bash
set -eo pipefail
source /opt/ros/jazzy/setup.bash
source /home/bjoern/.local/share/exciting-science/validation/highres-20261027/install/setup.bash
set -u
base=/home/bjoern/.local/share/exciting-science/validation/rviz-coexistence-20261027
native=/home/bjoern/.local/share/exciting-science/validation/highres-20261027
export PATH=/opt/ros/jazzy/bin:/usr/bin:/bin
export RMW_IMPLEMENTATION=rmw_fastrtps_cpp ROS_DOMAIN_ID=179 ROS_LOCALHOST_ONLY=1
export QT_QPA_PLATFORM=xcb DISPLAY=:2 XDG_RUNTIME_DIR=/run/user/1002
export VK_DRIVER_FILES=/usr/share/vulkan/icd.d/intel_icd.json
unset GALLIUM_DRIVER MESA_LOADER_DRIVER_OVERRIDE LIBGL_ALWAYS_SOFTWARE LD_PRELOAD
export AMENT_PREFIX_PATH="$base/assets:${AMENT_PREFIX_PATH}"
native_libpath="$LD_LIBRARY_PATH"
mkdir -p "$base/logs"
# Scene/start commands are supplied only after their resource review passes.
children=()
cleanup() {
  if ((${#children[@]})); then
    kill -INT "${children[@]}" 2>/dev/null || true
    sleep 1
    kill -TERM "${children[@]}" 2>/dev/null || true
    for child in "${children[@]}"; do wait "$child" 2>/dev/null || true; done
  fi
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
mkdir -p "$base/ui-validation"
/opt/ros/jazzy/lib/robot_state_publisher/robot_state_publisher --ros-args -r __ns:=/follower --params-file "$base/scene/rsp.yaml" > "$base/ui-validation/rsp.log" 2>&1 &
children+=("$!")
/usr/bin/python3 "$base/scene/visual_scene.py" --profile vga > "$base/ui-validation/scene.log" 2>&1 &
children+=("$!")
/opt/ros/jazzy/lib/rviz2/rviz2 -d "$base/scene/rviz-coexistence.rviz" > "$base/ui-validation/rviz.log" 2>&1 &
rviz_pid=$!; children+=("$rviz_pid")
export LD_LIBRARY_PATH="$native/scalar-sdk:$native_libpath"
setsid ros2 launch so101_station_vulkan resident_rgbd.launch.py backend:=vulkan profile:=vga serial:=243322071783 > "$base/ui-validation/camera.log" 2>&1 &
camera_launcher=$!
cleanup_ui() {
  kill -INT -- "-$camera_launcher" 2>/dev/null || true
  sleep 2
  kill -TERM -- "-$camera_launcher" 2>/dev/null || true
  wait "$camera_launcher" 2>/dev/null || true
  cleanup
}
trap cleanup_ui EXIT
sleep 12
/usr/bin/python3 /tmp/rviz-capture-window-20261027.py --config-filename rviz-coexistence.rviz --pid "$rviz_pid" --output "$base/ui-validation/rviz-window.png"

mkdir -p "$base/ui-validation/compositor-capture"
LD_LIBRARY_PATH="$base/runtime/usr/lib/x86_64-linux-gnu:$base/runtime/usr/lib/x86_64-linux-gnu/weston:$LD_LIBRARY_PATH" XDG_PICTURES_DIR="$base/ui-validation/compositor-capture" WAYLAND_DISPLAY=workshop-rviz timeout 10s "$base/runtime/usr/bin/weston-screenshooter" > "$base/ui-validation/screenshooter.log" 2>&1
