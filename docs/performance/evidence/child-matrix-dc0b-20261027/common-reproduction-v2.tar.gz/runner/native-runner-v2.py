from pathlib import Path
import hashlib,json,subprocess,sys,time
config=json.loads(Path(sys.argv[1]).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
for p,want in config['pins'].items():
 assert sha(p)==want,p
out=Path(config['output']);out.mkdir(exist_ok=False)
(out/'config.json').write_text(json.dumps(config,indent=2)+'\n')
handoff=json.loads(Path(config['handoff']).read_text());rows=[]
records=out/'wrapper-records';records.mkdir()
assert len(handoff['cases'])==58
for index,case in enumerate(handoff['cases'],1):
 name=case['name'];directory=out/name;assert not directory.exists()
 fixture=case['native_argv'][2]
 assert sha(fixture)==case['fixture_sha256'],name
 args=config['prefix_argv']+['/usr/bin/python3',config['watchdog'],str(directory),'--',config['qualifier'],'--vulkan',fixture,config['parent_shaders'],config['child_shaders'],str(directory/'result'),'--external-watchdog-ack']
 (records/(name+'.command.json')).write_text(json.dumps(args,indent=2)+'\n')
 start=time.monotonic()
 try:
  result=subprocess.run(args,capture_output=True,text=True,timeout=105)
 except subprocess.TimeoutExpired:
  (out/'terminal.json').write_text(json.dumps({'terminal':'wrapper_observation_timeout','case':name,'completed':len(rows),'qualified':False})+'\n')
  raise
 (records/(name+'.stdout')).write_text(result.stdout);(records/(name+'.stderr')).write_text(result.stderr)
 row={'case':name,'profile':case['profile'],'expected_unusable':case['expected_unusable'],'returncode':result.returncode,'process_lifetime_s_not_benchmark':time.monotonic()-start}
 jsonfile=directory/'result.json'
 if jsonfile.exists():
  data=json.loads(jsonfile.read_text());row['status']=data.get('status');row['fault']=data.get('fault');row['device']=data.get('device')
 rows.append(row);(out/'native-summary.json').write_text(json.dumps({'qualified':False,'scope':'native process execution; CPU exact comparison pending','rows':rows},indent=2)+'\n')
 print(f"{index}/58 {name}: exit={result.returncode} status={row.get('status')} fault={row.get('fault')}",flush=True)
 if result.returncode!=0 or row.get('status')!=('unusable' if case['expected_unusable'] else 'valid'):
  (out/'terminal.json').write_text(json.dumps({'terminal':'failed','case':name,'completed':len(rows),'qualified':False})+'\n')
  print(result.stderr[-4000:],flush=True)
  if (directory/'stderr.log').exists():print((directory/'stderr.log').read_text()[-4000:],flush=True)
  sys.exit(1)
post={p:sha(p)==want for p,want in config['pins'].items()}
(out/'post-run-pins.json').write_text(json.dumps(post,indent=2)+'\n');assert all(post.values())
(out/'terminal.json').write_text(json.dumps({'terminal':'native_completed','completed':len(rows),'post_pins_match':len(post),'qualified':False,'exact_comparison_pending':True})+'\n')
print('NATIVE_COMPLETE',len(rows),'PINS_MATCH',len(post),flush=True)
