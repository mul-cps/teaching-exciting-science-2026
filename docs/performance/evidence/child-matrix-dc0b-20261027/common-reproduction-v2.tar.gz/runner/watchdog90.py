#!/usr/bin/env python3
"""One explicitly released native hardware repro, isolated process-group deadline."""
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

if len(sys.argv) < 4 or sys.argv[2] != '--':
    raise SystemExit('usage: watchdog90.py NEW_OUTPUT_DIRECTORY -- COMMAND [ARGS...]')
out = Path(sys.argv[1])
out.mkdir(exist_ok=False)
command = sys.argv[3:]
started = time.monotonic()
with (out / 'stdout.log').open('xb') as stdout, (out / 'stderr.log').open('xb') as stderr:
    process = subprocess.Popen(command, stdout=stdout, stderr=stderr, start_new_session=True)
    timed_out = False
    try:
        returncode = process.wait(timeout=90)
    except subprocess.TimeoutExpired:
        timed_out = True
        os.killpg(process.pid, signal.SIGKILL)
        try:
            returncode = process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            returncode = None
record = {
    'scope': 'one_case_original_source_hardware_vulkan_diagnostic',
    'requested_backend': 'hardware_vulkan', 'hardware_vulkan_requested': True,
    'qualified': False, 'shader_execution_requested': True,
    'gpu_execution_status': 'not_inferred_from_process_status',
    'argv': command, 'process_group': process.pid,
    'watchdog_seconds': 90, 'kill_signal': 'SIGKILL' if timed_out else None,
    'timed_out': timed_out, 'returncode': returncode,
    'elapsed_s': time.monotonic() - started,
}
(out / 'watchdog.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
raise SystemExit(124 if timed_out else returncode)
