#!/usr/bin/env python3
"""Compile stock qualifier for candidate shader, parse offline; never execute Vulkan."""
import hashlib,json,pathlib,subprocess,shlex
root=pathlib.Path(__file__).resolve().parent
baseline=pathlib.Path('/tmp/workshop-child-intel-repro-20261027')
source=baseline/'source';libraries=baseline/'build'
sha=lambda f:hashlib.sha256(pathlib.Path(f).read_bytes()).hexdigest()
assert sha(source/'qualify_children.cpp')=='01e45df35f5e32f2310884de61a0e566cdd2b4a85fcc31f82be65fd57bb5999e'
assert sha(source/'src/children.cpp')=='77bb5aafe2caa5a9c106235f6baf936f691745d593ecda24ccaf0fe50e3c93c6'
library_pins={'libresident_parents.so': '0db2b40aae569e6f850b4979c95e319cfef4c6719e6f0bf576e7acf5fd90e759', 'libresident_children.so': 'adad74026157086c4539f75cdc6993c619b75eb0ceb26e760a92e460f0de56b6', 'libresident_rgbd.so': '22b797216208ebe0e96ed006a360692687f298a7d47801d0bbc3fab60ce928f2'}
for name,wanted in library_pins.items():assert sha(libraries/name)==wanted,name
shaderhash=sha(root/'children.slang')
assert (root/'child-shaders/source.sha256').read_text()==shaderhash+'\n'
for spv in (root/'child-shaders').glob('*.spv'):
 assert (spv.parent/(spv.name+'.sha256')).read_text()==sha(spv)+'  '+spv.name+'\n'
assert len(list((root/'child-shaders').glob('*.spv')))==21
compiler='/usr/bin/g++'
version=subprocess.check_output([compiler,'--version'],text=True);assert '13.' in version
command=[compiler,'-std=c++17','-O2','-ffp-contract=off','-pthread','-I',str(source/'include'),str(source/'qualify_children.cpp'),
 '-DCHILD_QUALIFIER_SOURCE_SHA256="'+sha(source/'qualify_children.cpp')+'"',
 '-DCHILD_MODULE_SOURCE_SHA256="'+sha(source/'src/children.cpp')+'"',
 '-DCHILD_SHADER_SOURCE_SHA256="'+shaderhash+'"','-L',str(libraries),'-Wl,-rpath,'+str(libraries),
 '-lresident_children','-lresident_parents','-lresident_rgbd','-lvulkan','-ldl','-o',str(root/'qualify_children')]
(root/'compile-command.json').write_text(json.dumps(command,indent=2)+'\n')
subprocess.run(command,check=True)
fixture=baseline/'literal-configured-min-reject24.childq'
assert sha(fixture)=='e85eb99b89f9173a5ffd50f85638d8b5542dd482f90100d116012da9c368c3dd'
result=subprocess.check_output([str(root/'qualify_children'),'--offline',str(fixture)],text=True)
assert json.loads(result)['gpu_executed'] is False
(root/'offline.json').write_text(result)
run=['env','-u','DISPLAY','-u','WAYLAND_DISPLAY','-u','VK_ICD_FILENAMES','-u','VK_ADD_DRIVER_FILES','-u','VK_LOADER_DRIVERS_SELECT','-u','VK_LOADER_DRIVERS_DISABLE','-u','LD_PRELOAD',
 'LD_LIBRARY_PATH='+str(libraries),'VK_DRIVER_FILES=/usr/share/vulkan/icd.d/intel_icd.json','/usr/bin/python3',str(baseline/'watchdog90.py'),str(root/'one-case-run'),'--',str(root/'qualify_children'),'--vulkan',str(fixture),str(baseline/'parent-shaders-NOT-USED-literal-profile'),str(root/'child-shaders'),str(root/'one-case-run/result'),'--external-watchdog-ack']
(root/'pending-run-command.json').write_text(json.dumps(run,indent=2)+'\n')
(root/'pending-run-command.txt').write_text('NOT EXECUTED. Root owns bounded native release.\n'+shlex.join(run)+'\n')
print('CPU compile/offline only complete; GPU command saved and NOT executed.')
